<?php
$username = "root";
$password = "";
$hostname = "localhost";
$dbname = "pemantau_cuaca";

// Create connection
$conn = mysqli_connect($hostname, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Menampilkan semua data
// $sql = "SELECT waktu, Hum, Temp, Latitude, Longitude, Wind FROM pemantau";

// format Menampilkan data terakhir atau terbaru
// $sql = "SELECT field FROM database_name ORDER BY id DESC LIMIT 1;";

// Menampilkan data terakhir atau terbaru dengan variabel tinggi dari database skripsi
$sql = "SELECT Waktu, Latitude, Longitude, Temperature, Humidity, Pressure, Altitude FROM skripsi ORDER BY id DESC LIMIT 1;";


$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0){
	
	// output data of each row
	while($row = mysqli_fetch_assoc($result)){
		
		// memanggil nilai di var waktu dengan memberi nama Waktu
		// echo " Waktu: " . $row ["waktu"]. " Kelembaban: " . $row["Hum"]. " Temperature: " . $row["Temp"]. " Lat: " . $row["Latitude"]. " Long: " . $row["Longitude"]. " Kecepatan Angin: " . $row["Wind"].
		// "<br>";

		
// Dengan variabel tinggi
		$myObj = array(
			 'waktu' => $row ["Waktu"],
			 'temp' => $row["Temperature"],
			 'hum' => $row["Humidity"],
			 'lokasi1' => $row["Latitude"].",". $row["Longitude"],
			 'press'=> $row["Pressure"],
			 'alti'=> $row["Altitude"]
		);


		$myJSON = json_encode($myObj);

		echo $myJSON;
	}
} else{
	echo "0 results";
}


//close the connection
mysqli_close($conn);
?>