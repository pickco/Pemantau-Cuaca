<!DOCTYPE html>
<html>
<head>
    <title> Pemantau Cuaca Berbasis Arduino </title>

    <script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
    <script type="text/javascript">
    </script>
    <script type="text/javascript">
        
        function load(){
            // console.log('called')
            var xhr = new XMLHttpRequest();

            xhr.onload = function () {
                var res = JSON.parse(this.response)
                $('#waktu .value').text(res.waktu)
                $('#hum .value').text(res.hum)
                $('#temp .value').text(res.temp)
                $('#lokasi1 .value').text(res.lokasi1)
                $('#press .value').text(res.press)
                $('#alti .value').text(res.alti)
            };

            xhr.open('GET', 'config1.php', true);
            xhr.send();
        }
        var auto_refresh = setInterval(load, 1000);
    </script>
    <!-- Import Library -->
    <link rel="stylesheet" href="../pemantau-cuaca/assets/bootstrap.min.css">
    <link rel="stylesheet" href="../pemantau-cuaca/assets/weather-icons-master/css/weather-icons.css">
    <link rel="stylesheet" href="../pemantau-cuaca/assets/weather-icons-master/css/weather-icons.min.css">
    <link rel="stylesheet" href="../pemantau-cuaca/assets/weather-icons-master/css/weather-icons-wind.css">
    <link rel="stylesheet" href="../pemantau-cuaca/assets/weather-icons-master/css/weather-icons-wind.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- <link href="../assets/paper-dashboard.css" rel="stylesheet"> -->
    <!-- <link href="../assets/ui.css" rel="stylesheet"> -->

</head>

<!-- <body onload="JavaScript:AutoRefresh(1000);"> -->
<body>
    <div class="main-panel">
        <navbar-cmp _ngcontent-c0=""><nav class="navbar navbar-default">
            <div class="container-fluid">
            <div class="navbar-header">
                <a class="navbar-brand" href="#">Pemantau Cuaca</a>
            </div>
            </div>
        </nav></navbar-cmp>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
            <div class="col-lg-3 col-sm-6">
                <div class="card" id="waktu">
                    <div class="content">
                        <div class="row">
                            <div class="col-xs-5">
                                <div class="icon-big icon-basic text-center">
                                    <i class="wi wi-time-1"></i>
                                </div>
                            </div>
                            <div class="col-xs-7">
                                <div class="numbers">
                                    <p>Waktu</p>
                                    <p class="value">Tanggal dan Jam</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="card" id="temp">
                    <div class="content">
                        <div class="row">
                            <div class="col-xs-5">
                                <div class="icon-big icon-themperature text-center">
                                    <i class="wi wi-thermometer-exterior"></i>
                                </div>
                            </div>
                            <div class="col-xs-7">
                                <div class="numbers">
                                    <p>Temperature</p>
                                    <p class="value">Temperature</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="card" id="hum">
                    <div class="content">
                        <div class="row">
                            <div class="col-xs-5">
                                <div class="icon-big icon-humdity text-center">
                                    <i class="wi wi-humidity"></i>
                                </div>
                            </div>
                            <div class="col-xs-7">
                                <div class="numbers">
                                    <p>Kelembaban</p>
                                    <p class="value">Humdity</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="card" id="press">
                    <div class="content">
                        <div class="row">
                            <div class="col-xs-5">
                                <div class="icon-big icon-wind text-center">
                                    <i class="wi wi-barometer"></i>
                                </div>
                            </div>
                            <div class="col-xs-7">
                                <div class="numbers">
                                    <p>Tekanan Udara</p>
                                    <p class="value"> Pressure </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="card" id="lokasi1">
                    <div class="content">
                        <div class="row">
                            <div class="col-xs-5">
                                <div class="icon-big icon-basic text-center">
                                    <i class="fa fa-map-marker" style="font-size:52px;color:red"></i>
                                </div>
                            </div>
                            <div class="col-xs-7">
                                <div class="numbers">
                                    <p>Lokasi</p>
                                    <p class="value"> Location </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="card" id="alti">
                    <div class="content">
                        <div class="row">
                            <div class="col-xs-5">
                                <div class="icon-big icon-wind text-center">
                                    <i class="wi wi-na"></i>
                                </div>
                            </div>
                            <div class="col-xs-7">
                                <div class="numbers">
                                    <p> Ketinggian </p>
                                    <p class="value"> Altitude </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                </div>
            </div>
        </div>
    </div>
<!--    <div id="header" class="item1">
    Pemantau Cuaca
    </div>
    <div id="isi">
        <div id="load_content">
            <?php
            include "config1.php"
            // $query = mysqli_query($connection,"SELECT * FROM 'pemantau' ");
            ?>
        </div>
    </div> -->

    <div id="footer" class="panel-footer">
        Created by Nur Indra Perkasa
    </div>
</body>
</html>